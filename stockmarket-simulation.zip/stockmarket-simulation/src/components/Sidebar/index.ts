import { Sidebar } from './Sidebar';

export default Sidebar;