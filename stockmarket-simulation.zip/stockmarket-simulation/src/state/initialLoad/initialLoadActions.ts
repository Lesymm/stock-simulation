export const LOAD_STATE = 'load-state-initial';

export const loadState = () => ( {
    type: LOAD_STATE
} );