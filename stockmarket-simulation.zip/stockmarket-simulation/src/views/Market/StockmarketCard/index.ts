import StockmarketCard from './StockmarketCard';

export default StockmarketCard;