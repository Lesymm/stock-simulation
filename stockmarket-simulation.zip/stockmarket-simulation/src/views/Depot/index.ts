import Depot from './Depot';

export default Depot;